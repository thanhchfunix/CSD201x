
public class VNFlight extends Flight {  
     
    //behaviors
    public VNFlight() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
        
    }

    public VNFlight(String route, String flightNo, double fare) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
        
    }
    
    /*Complete the below function for second test case*/
    public double getSaleFare() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }  
    
    @Override
    public String toString() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
    //add and complete your other methods here (if needed)

}
