
public class Flight {

    public Flight() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    public Flight(String route, double fare) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    public double getFare() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    public String getRoute() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    //add and complete your other methods here (if needed)
}
